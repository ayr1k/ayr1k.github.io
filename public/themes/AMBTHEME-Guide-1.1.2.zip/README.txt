AMBTHEME 1.1.2

Extract this ZIP and read THEMES.md or zh-CN/THEMES.md. Import the .ambtheme examples separately. The starter supports 1.1.0; updated Alloy uses the 1.1.2 text-offset feature.

请先解压并阅读帮助，再导入 .ambtheme。基础示例兼容 1.1.0，新版 Alloy 使用 1.1.2 字体偏移功能。
